// Acceso directo a LANDUR en el modo portal. Autentica contra /auth/login con
// la misma cuenta RIVECT (AuthStore) y vuelve a /landur/ sin pasar por el
// selector de proyectos. El HTML lo sirve namecheap/server/landur.mjs.
const form = document.getElementById('f');
const errorBox = document.getElementById('error');
form.addEventListener('submit', async event => {
  event.preventDefault();
  const button = form.querySelector('button');
  button.disabled = true;
  errorBox.textContent = '';
  const email = form.elements.email.value.trim();
  const password = form.elements.password.value;
  try {
    const response = await fetch('/auth/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      credentials: 'same-origin',
      body: JSON.stringify({ email, password }),
    });
    let data = null;
    try { data = await response.json(); } catch { /* respuesta vacía o proxy intermedio */ }
    if (!response.ok) {
      errorBox.textContent = (data && data.error) || 'No se pudo iniciar sesión.';
      button.disabled = false;
      return;
    }
    location.assign('/landur/');
  } catch {
    errorBox.textContent = 'No se pudo conectar. Verificá tu conexión e intentá otra vez.';
    button.disabled = false;
  }
});
