# Cambios LANDUR — listos para push

Carpeta con todos los archivos de la rama `landur/integraciones-final`
(base: commit `6f4b3b7` de `main`).

Las rutas internas respetan la estructura exacta del repositorio: hay que
copiar el contenido de esta carpeta sobre la raíz del repo y luego commitear.

## Sobrescribir (16 archivos modificados)

- `namecheap/server/landur.mjs` — login directo `/landur/login`, sin vuelta al panel
- `namecheap/server/main.mjs` — ruta `/landur/login` en el whitelist
- `projects/landur/README.md` — documentación del flujo nuevo e integraciones
- `projects/landur/docs/API.md` — 5 rutas nuevas (conexiones y sync)
- `projects/landur/docs/PORTAL-RIVECT.md` — flujo de sesión directo
- `projects/landur/public/app.js` — tarjeta de conexiones, brand nuevo, lock directo
- `projects/landur/public/styles.css` — estilos de conexiones
- `projects/landur/public/brand.png` — logo nuevo
- `projects/landur/public/icon-192.png` — logo nuevo
- `projects/landur/public/icon-512.png` — logo nuevo
- `projects/landur/public/apple-touch-icon.png` — logo nuevo
- `projects/landur/scripts/qa-portal.mjs` — ajustes de QA al flujo nuevo
- `projects/landur/server/app.mjs` — rutas de integraciones en el servidor autónomo
- `projects/landur/server/ledger.mjs` — migración de la tabla `connections`
- `scripts/cpanel-deploy.mjs` — rutas gestionadas ampliadas
- `tests/portal-projects.test.mjs` — expectativas del flujo sin “Mis proyectos”

## Agregar (5 archivos nuevos)

- `namecheap/public/landur-brand.png` — logo del login del portal
- `namecheap/public/landur-login.js` — envío del login directo
- `projects/landur/server/integrations.mjs` — motor Shopify + Meta Ads
- `projects/landur/tests/helpers/integrations-fixture.mjs` — proveedores simulados
- `projects/landur/tests/integrations.test.mjs` — 6 pruebas de integraciones

## Después de copiar

```bash
git checkout -b landur/integraciones-final
git add -A
git commit -m "landur: logo nuevo, login directo e integraciones Shopify/Meta Ads"
git push -u origin landur/integraciones-final
```
